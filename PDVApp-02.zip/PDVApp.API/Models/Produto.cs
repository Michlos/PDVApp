﻿namespace PDVApp.API.Models
{
    public class Produto
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
        public string Descricao { get; set; } = string.Empty;
        public decimal PrecoCompra { get; set; } = 0.0m;
        public decimal PrecoVenda { get; set; } = 0.0m;
        public int Estoque { get; set; } = 0;
        public DateTime DataCadastro { get; set; } = DateTime.Now;
        public bool Ativo { get; set; } = true;
        public int CategoriaId { get; set; }
        public Categoria Categoria { get; set; } = new Categoria();
        public List<ProdutoVenda> Vendas { get; set; } = new List<ProdutoVenda>();
        public List<ProdutoEstoqueHistorico> EstoqueHistorico { get; set; } = new List<ProdutoEstoqueHistorico>();
        public List<ProdutoPrecoHistorico> PrecoHistorico { get; set; } = new List<ProdutoPrecoHistorico>();


    }
}
