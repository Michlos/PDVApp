﻿namespace PDVApp.API.Models
{
    public class ProdutoPrecoHistorico
    {
    }
}