﻿namespace PDVApp.API.Models
{
    public class Movimentacao
    {
    }
}