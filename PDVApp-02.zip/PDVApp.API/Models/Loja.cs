﻿namespace PDVApp.API.Models
{
    public class Loja
    {
    }
}
