﻿namespace PDVApp.API.Models
{
    public class Caixa
    {
        public int Id { get; set; }
        public DateTime DataAbertura { get; set; } = DateTime.Now;
        public DateTime? DataFechamento { get; set; } = null;
        public decimal SaldoInicial { get; set; } = 0.0m;
        public decimal SaldoFinal { get; set; } = 0.0m;
        public bool Fechado { get; set; } = false;
        public List<Venda> Vendas { get; set; } = new List<Venda>();
        public List<Movimentacao> Movimentacoes { get; set; } = new List<Movimentacao>();
    }
}
