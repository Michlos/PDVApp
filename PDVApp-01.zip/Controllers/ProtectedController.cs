﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace PDVApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProtectedController : ControllerBase
    {
        private readonly ILogger<ProtectedController> _logger;

        public ProtectedController(ILogger<ProtectedController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        [Authorize]
        public IActionResult GetSecret()
        {
            _logger.LogInformation("Endpoint protegido acessado por: {User}", User.Identity?.Name ?? "anônimo");
            return Ok("Você acessou um endpoint protegido com JWT!");
        }
    }
}
